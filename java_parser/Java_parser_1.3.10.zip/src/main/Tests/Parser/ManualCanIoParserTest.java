package Parser;

import Parser.Models.IO.McanIoProperty;
import Parser.Models.IO.RecordIoPropertyModel;
import Primary.Converter;
import org.junit.Test;

public class ManualCanIoParserTest {


}
