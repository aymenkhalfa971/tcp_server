﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;


[assembly: AssemblyCompany("UAB Teltonika")]
[assembly: AssemblyProduct("Teltonika.Parser")]
[assembly: AssemblyCopyright("Copyright © UAB Teltonika 2011 - 2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.8.0.*")]
