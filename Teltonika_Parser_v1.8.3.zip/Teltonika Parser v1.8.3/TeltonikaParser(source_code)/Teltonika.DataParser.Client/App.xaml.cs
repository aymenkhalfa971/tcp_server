﻿using System.Windows;

namespace Teltonika.DataParser.Client
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        
    }
}
