﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;


[assembly: AssemblyTitle("Teltonika.DataParser.Client")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
